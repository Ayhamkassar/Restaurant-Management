﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurant_V2
{
    public partial class Form1 : Form
    {
        public string admin2 = "Abd_Alkadier";
        public string passadmin = "12345";
        public string casher = "null";
        public string passcasher = "null";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.Size = new Size(70, 45);
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.Size = new Size(60 , 35);
        }

        private void SignUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login.Text = "Sign Up!";
            int x = button1.Location.X;
            int y = button1.Location.Y;
            for (int i = x; i < 192; i++)
            {
                x++;
                button1.Location = new Point(x,y);
            }
            x = Back.Location.X; y = Back.Location.Y;
            for (int i = x; i < 85; i++)
            {
                x++;
                Back.Location = new Point(x,y);
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            Login.Text = "Login";
            int x = button1.Location.X;
            int y = button1.Location.Y;
            for (int i = x; i > 140; i--)
            {
                x--;
                button1.Location = new Point(x, y);
            }
            x = Back.Location.X;
            y = Back.Location.Y;
            for (int i = x; i > -62; i--)
            {
                x--;
                Back.Location = new Point(x, y);
            }

        }

        private void Back_MouseEnter(object sender, EventArgs e)
        {
            Back.Size = new Size(70, 45);
        }

        private void Back_MouseLeave(object sender, EventArgs e)
        {
            Back.Size = new Size(60, 35);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Login.Text == "Sign Up!")
            {
                    if (string.IsNullOrEmpty(Username.Text) || string.IsNullOrEmpty(Password.Text))
                    {
                        MessageBox.Show("somthing went wrong", "Error", MessageBoxButtons.OK);
                        return;
                    }
                    else
                    {
                        if (admin2 != null)
                        {
                            if (Username.Text != admin2)
                            {
                                MessageBox.Show("signed up as a cashier", "Ok", MessageBoxButtons.OK);
                                casher = Username.Text;
                                passcasher = Password.Text;
                            }
                            else
                            {
                                MessageBox.Show("There is an admin with this name", "Error", MessageBoxButtons.OK);
                            }
                            return;
                        }
                        else
                        {
                            MessageBox.Show("No Admin,Please Add one.", "Error",MessageBoxButtons.OK);
                        }
                    }
            }
            else
            {
               if (Username.Text == admin2 && Password.Text == passadmin)
               {
                    admin2 admin = new admin2();
                    this.Hide();
                    admin.Show();
               }
               else if (Username.Text == casher && Password.Text == passcasher)
                {
                    Cashier cashier = new Cashier();
                    this.Hide();
                    cashier.Show();
                }
               else
               {
                   MessageBox.Show("Either Password or UserName are wrong", "Error",MessageBoxButtons.OK);
                   return;
               }
            }
        }

        private void Username_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

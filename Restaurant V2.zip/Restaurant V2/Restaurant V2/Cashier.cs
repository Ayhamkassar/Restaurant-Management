﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Restaurant_V2
{
    public partial class Cashier : Form
    {
        private string Number;
        private string method = "";
        private static string Default = "Data Source=.;database=RestaurantV2;Integrated security=True";
        private static string Bills = "Data Source=.;database=BillsV2;Integrated security=True";
        private int i = 1;
        private string The_Price = "";
        private bool IsNotEmpty = false;
        private int cnt = 0;
        private int total = 0;
        OutOrder outOrder = new OutOrder();
        Table table = new Table();
        public Cashier()
        {
            InitializeComponent();
        }

        private void Cashier_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(Default);
                using (SqlCommand cmd = new SqlCommand("SELECT * from Foods", conn))
                {
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        DataTable dt = new DataTable();
                        dt.Load(reader);
                        FoodList.DataSource = dt;
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void more_Click(object sender, EventArgs e)
        {
            i++;
            method = "+";
            Amount.Text = i.ToString();
        }

        private void less_Click(object sender, EventArgs e)
        {
            if (i != 1)
            {
                i--; method = "-";
                Amount.Text = i.ToString();
            }
            else
            {
                Bill.Items.Clear();
                The_Price = "";
                method = "";
                Total.Text = "0";
            }
            method = "";
        }

        private void Amount_TextChanged(object sender, EventArgs e)
        {
            if (Amount.Text != "0")
            {
                if (The_Price != "")
                {
                    if (method == "+")
                    {
                        int amount = Convert.ToInt32(The_Price);
                        int price = Convert.ToInt32(Total.Text);
                        Total.Text = (amount + price).ToString();
                    }
                    if (method == "-")
                    {
                        int amount = Convert.ToInt32(The_Price);
                        int price = Convert.ToInt32(Total.Text);
                        Total.Text = (price - amount).ToString();
                    }
                }
            }
            else
            {
                Total.Text = "0";
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

            if (IsNotEmpty)
            {
                total += Convert.ToInt32(Total.Text);
                SqlConnection conn = new SqlConnection(Bills);
                if (!InOrder.Checked)
                {
                    outOrder.cleared();
                    DialogResult result = MessageBox.Show("are you sure?", "Notification", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        cnt++;
                        using (SqlCommand cmd = new SqlCommand("INSERT INTO Bill (Name,Total,Date) Values(@name,@price,@date)", conn))
                        {
                            conn.Open();
                            cmd.Parameters.AddWithValue("@name", "The Bill " + cnt);
                            cmd.Parameters.AddWithValue("@price", " Price " + total);
                            cmd.Parameters.AddWithValue("@date", DateTime.Now.ToString());
                            cmd.ExecuteNonQuery();
                            conn.Close();
                        }
                        MessageBox.Show("Order sent", "Notification", MessageBoxButtons.OK);
                        IsNotEmpty = false;
                        Bill.Items.Clear();
                        i = 1;
                        Amount.Text = "0";
                        The_Price = "";
                        method = "";
                        outOrder.order();
                    }
                    return;
                }
                DialogResult result2 = MessageBox.Show("are you sure?", "Notification", MessageBoxButtons.YesNo);
                if (result2 == DialogResult.Yes)
                {
                    cnt++;
                    using (SqlCommand cmd = new SqlCommand("INSERT into Bill (Name,Total,Date) Values(@name,@price,@date)", conn))
                    {
                        conn.Open();
                        cmd.Parameters.AddWithValue("@name", " Bill Number " + cnt + " Price ");
                        cmd.Parameters.AddWithValue("@price", total);
                        cmd.Parameters.AddWithValue("@date", DateTime.Now.ToString());
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                    MessageBox.Show("Order sent", "Notification", MessageBoxButtons.OK);
                    table.Entered();
                    Bill.Items.Clear();
                    i = 1;
                    Amount.Text = "0";
                    The_Price = "";
                    method = "";
                    IsNotEmpty = false;
                }
            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            if (IsNotEmpty)
            {
                DialogResult result = MessageBox.Show("are you sure?", "Notification", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Order canceled", "Notification", MessageBoxButtons.OK);
                    IsNotEmpty = false;
                    Bill.Items.Clear();
                    i = 1;
                    Amount.Text = i.ToString();
                    Total.Text = "0";
                    The_Price = "";
                    method = "";
                }
            }
        }

        private void FoodList_Click(object sender, EventArgs e)
        {
        }

        private void OutOrder_Click(object sender, EventArgs e)
        {
            outOrder.Show();
        }

        private void InOrders_Click(object sender, EventArgs e)
        {
            table.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Hide();
        }

        private void FoodList_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            Number = FoodList.Rows[e.RowIndex].Cells[0].Value.ToString();
            i = 1;
            total += Convert.ToInt32(Total.Text);
            Amount.Text = i.ToString();
            SqlConnection conn = new SqlConnection(Default);
            using (SqlCommand cmd = new SqlCommand("SELECT Name,Price from Foods where ID=@id", conn))
            {
                cmd.Parameters.AddWithValue("@id", Number);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Bill.Items.Add((reader["Name"].ToString() + " " + reader["Price"].ToString() + " " + "X" + i));
                        Total.Text = reader["Price"].ToString();
                    }
                }
                conn.Close();
                IsNotEmpty = true;
                method = "+";
                The_Price = Total.Text;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurant_V2
{
    public partial class Table : Form
    {
        public int cnt = 0;
        public  bool[] IsEntered = new bool[16];

        public Table()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

            Label label = (Label)sender;

            for (int i = 1; i <= IsEntered.Length; i++)
            {
                if (label.Name == "label" + i)
                {
                    label.Text = "Empty";
                    label.ForeColor = Color.Lime;
                    IsEntered[i - 1] = false;
                }
            }
        }
        public void Entered()
        {
            for (int i = 0; ; i++)
            {
                if (!IsEntered[i])
                {
                    break;
                }
                if (i == IsEntered.Length)
                {
                    MessageBox.Show("all Tables Are Full", "Notification", MessageBoxButtons.OK);
                    return;
                }
            }
            Random random = new Random();
            int rand = random.Next(0, 9);
            while (IsEntered[rand])
            {
                rand = random.Next(0, 9);
            }
            IsEntered[rand] = true;

            if (rand == 0) { label1.Text = "full"; label1.ForeColor = Color.Red; }
            if (rand == 1) { label2.Text = "full"; label2.ForeColor = Color.Red; }
            if (rand == 2) { label3.Text = "full"; label3.ForeColor = Color.Red; }
            if (rand == 3) { label4.Text = "full"; label4.ForeColor = Color.Red; }
            if (rand == 4) { label5.Text = "full"; label5.ForeColor = Color.Red; }
            if (rand == 5) { label6.Text = "full"; label6.ForeColor = Color.Red; }
            if (rand == 6) { label7.Text = "full"; label7.ForeColor = Color.Red; }
            if (rand == 7) { label8.Text = "full"; label8.ForeColor = Color.Red; }
            if (rand == 8) { label9.Text = "full"; label9.ForeColor = Color.Red; }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Cashier cashier = new Cashier();
            cashier.Show();
            this.Hide();
        }
    }
}

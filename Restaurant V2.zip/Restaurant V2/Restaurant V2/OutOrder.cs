﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurant_V2
{
    public partial class OutOrder : Form
    {
        public int i = 1;
        public OutOrder()
        {
            InitializeComponent();
        }
        public void order()
        {
            Orders.Items.Add("processing Order Number " + i);
            i++;

        }

        private void Orders_ItemCheck(object sender, ItemCheckEventArgs e)
        {

            try
            {
                if (Orders.Items.Count != 1)
                {
                    Orders.Items.Remove(Orders.SelectedItem);
                }
                else
                {
                    Orders.Items.Remove(Orders.SelectedItem);
                    Orders.Items.Add("لا يوجد طلبات");
                    Orders.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ: " + ex.Message);
            }
        }

        public void cleared()
        {
            if (!Orders.Enabled)
            {
                Orders.Enabled = true;
                Orders.Items.Clear();
            }
        }

        private void OutOrder_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Cashier cashier = new Cashier();
            cashier.Show();
            this.Hide();
        }
    }
}

﻿namespace Restaurant_V2
{
    partial class Cashier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.FoodList = new Guna.UI2.WinForms.Guna2DataGridView();
            this.InOrders = new Guna.UI2.WinForms.Guna2Button();
            this.OutOrder = new Guna.UI2.WinForms.Guna2Button();
            this.Total = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Cancel = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.InOrder = new Guna.UI2.WinForms.Guna2CheckBox();
            this.Bill = new System.Windows.Forms.ListBox();
            this.less = new Guna.UI2.WinForms.Guna2CircleButton();
            this.more = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Amount = new Guna.UI2.WinForms.Guna2TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.FoodList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // FoodList
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.FoodList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.FoodList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.FoodList.ColumnHeadersHeight = 4;
            this.FoodList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.FoodList.DefaultCellStyle = dataGridViewCellStyle3;
            this.FoodList.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.FoodList.Location = new System.Drawing.Point(-1, -2);
            this.FoodList.Name = "FoodList";
            this.FoodList.ReadOnly = true;
            this.FoodList.RowHeadersVisible = false;
            this.FoodList.RowHeadersWidth = 51;
            this.FoodList.RowTemplate.Height = 26;
            this.FoodList.Size = new System.Drawing.Size(484, 513);
            this.FoodList.TabIndex = 25;
            this.FoodList.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.FoodList.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.FoodList.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.FoodList.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.FoodList.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.FoodList.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.FoodList.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.FoodList.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.FoodList.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.FoodList.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Tahoma", 8F);
            this.FoodList.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.FoodList.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.FoodList.ThemeStyle.HeaderStyle.Height = 4;
            this.FoodList.ThemeStyle.ReadOnly = true;
            this.FoodList.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.FoodList.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.FoodList.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Tahoma", 8F);
            this.FoodList.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.FoodList.ThemeStyle.RowsStyle.Height = 26;
            this.FoodList.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.FoodList.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.FoodList.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.FoodList_CellMouseClick);
            this.FoodList.Click += new System.EventHandler(this.FoodList_Click);
            // 
            // InOrders
            // 
            this.InOrders.BackColor = System.Drawing.Color.Transparent;
            this.InOrders.BorderRadius = 16;
            this.InOrders.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.InOrders.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.InOrders.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.InOrders.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.InOrders.FillColor = System.Drawing.Color.Coral;
            this.InOrders.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.InOrders.ForeColor = System.Drawing.Color.White;
            this.InOrders.Location = new System.Drawing.Point(511, 254);
            this.InOrders.Name = "InOrders";
            this.InOrders.Size = new System.Drawing.Size(164, 39);
            this.InOrders.TabIndex = 39;
            this.InOrders.Text = "الطلبات الداخلية";
            this.InOrders.Click += new System.EventHandler(this.InOrders_Click);
            // 
            // OutOrder
            // 
            this.OutOrder.BackColor = System.Drawing.Color.Transparent;
            this.OutOrder.BorderRadius = 16;
            this.OutOrder.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.OutOrder.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.OutOrder.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.OutOrder.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.OutOrder.FillColor = System.Drawing.Color.Coral;
            this.OutOrder.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.OutOrder.ForeColor = System.Drawing.Color.White;
            this.OutOrder.Location = new System.Drawing.Point(681, 254);
            this.OutOrder.Name = "OutOrder";
            this.OutOrder.Size = new System.Drawing.Size(150, 39);
            this.OutOrder.TabIndex = 38;
            this.OutOrder.Text = "الطلبات الخارجية";
            this.OutOrder.Click += new System.EventHandler(this.OutOrder_Click);
            // 
            // Total
            // 
            this.Total.AutoSize = true;
            this.Total.BackColor = System.Drawing.Color.Transparent;
            this.Total.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 18F);
            this.Total.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Total.Location = new System.Drawing.Point(645, 313);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(30, 35);
            this.Total.TabIndex = 37;
            this.Total.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 15F);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(764, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 29);
            this.label2.TabIndex = 36;
            this.label2.Text = ":الكمية";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 15F);
            this.label1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.label1.Location = new System.Drawing.Point(759, 313);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 29);
            this.label1.TabIndex = 35;
            this.label1.Text = ":السعر";
            // 
            // Cancel
            // 
            this.Cancel.BackColor = System.Drawing.Color.Transparent;
            this.Cancel.BorderRadius = 9;
            this.Cancel.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Cancel.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Cancel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Cancel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Cancel.FillColor = System.Drawing.Color.Red;
            this.Cancel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Cancel.ForeColor = System.Drawing.Color.White;
            this.Cancel.Location = new System.Drawing.Point(489, 424);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(342, 45);
            this.Cancel.TabIndex = 34;
            this.Cancel.Text = "إلغاء الطلب";
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderRadius = 9;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.Green;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(489, 373);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(342, 45);
            this.guna2Button1.TabIndex = 33;
            this.guna2Button1.Text = "إرسال للمطبخ";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // InOrder
            // 
            this.InOrder.AutoSize = true;
            this.InOrder.BackColor = System.Drawing.Color.Transparent;
            this.InOrder.Checked = true;
            this.InOrder.CheckedState.BorderColor = System.Drawing.Color.Black;
            this.InOrder.CheckedState.BorderRadius = 0;
            this.InOrder.CheckedState.BorderThickness = 0;
            this.InOrder.CheckedState.FillColor = System.Drawing.Color.Black;
            this.InOrder.CheckMarkColor = System.Drawing.Color.Lime;
            this.InOrder.CheckState = System.Windows.Forms.CheckState.Checked;
            this.InOrder.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InOrder.ForeColor = System.Drawing.SystemColors.ControlText;
            this.InOrder.Location = new System.Drawing.Point(685, 220);
            this.InOrder.Name = "InOrder";
            this.InOrder.Size = new System.Drawing.Size(146, 28);
            this.InOrder.TabIndex = 32;
            this.InOrder.Text = "طلب داخلي";
            this.InOrder.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.InOrder.UncheckedState.BorderRadius = 0;
            this.InOrder.UncheckedState.BorderThickness = 0;
            this.InOrder.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.InOrder.UseVisualStyleBackColor = false;
            // 
            // Bill
            // 
            this.Bill.FormattingEnabled = true;
            this.Bill.ItemHeight = 16;
            this.Bill.Location = new System.Drawing.Point(511, 130);
            this.Bill.Name = "Bill";
            this.Bill.Size = new System.Drawing.Size(320, 84);
            this.Bill.TabIndex = 31;
            // 
            // less
            // 
            this.less.BackColor = System.Drawing.Color.Transparent;
            this.less.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.less.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.less.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.less.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.less.FillColor = System.Drawing.Color.Firebrick;
            this.less.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.less.ForeColor = System.Drawing.Color.White;
            this.less.Location = new System.Drawing.Point(643, 94);
            this.less.Name = "less";
            this.less.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.less.Size = new System.Drawing.Size(44, 28);
            this.less.TabIndex = 28;
            this.less.Text = "-";
            this.less.Click += new System.EventHandler(this.less_Click);
            // 
            // more
            // 
            this.more.BackColor = System.Drawing.Color.Transparent;
            this.more.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.more.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.more.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.more.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.more.FillColor = System.Drawing.Color.Green;
            this.more.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.more.ForeColor = System.Drawing.Color.White;
            this.more.Location = new System.Drawing.Point(693, 94);
            this.more.Name = "more";
            this.more.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.more.Size = new System.Drawing.Size(44, 28);
            this.more.TabIndex = 27;
            this.more.Text = "+";
            this.more.Click += new System.EventHandler(this.more_Click);
            // 
            // Amount
            // 
            this.Amount.BorderRadius = 15;
            this.Amount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Amount.DefaultText = "1";
            this.Amount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Amount.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Amount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Amount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Amount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Amount.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Amount.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Amount.Location = new System.Drawing.Point(777, 95);
            this.Amount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Amount.Name = "Amount";
            this.Amount.PasswordChar = '\0';
            this.Amount.PlaceholderText = "";
            this.Amount.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Amount.SelectedText = "";
            this.Amount.Size = new System.Drawing.Size(54, 28);
            this.Amount.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.Amount.TabIndex = 26;
            this.Amount.TextChanged += new System.EventHandler(this.Amount_TextChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::Restaurant_V2.Properties.Resources.X;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(786, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(55, 58);
            this.pictureBox2.TabIndex = 40;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Cashier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restaurant_V2.Properties.Resources.TheBackGround;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(839, 481);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.FoodList);
            this.Controls.Add(this.InOrders);
            this.Controls.Add(this.OutOrder);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.InOrder);
            this.Controls.Add(this.Bill);
            this.Controls.Add(this.less);
            this.Controls.Add(this.more);
            this.Controls.Add(this.Amount);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Cashier";
            this.Text = "Cashier";
            this.Load += new System.EventHandler(this.Cashier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FoodList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2DataGridView FoodList;
        private Guna.UI2.WinForms.Guna2Button InOrders;
        private Guna.UI2.WinForms.Guna2Button OutOrder;
        private System.Windows.Forms.Label Total;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button Cancel;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2CheckBox InOrder;
        private System.Windows.Forms.ListBox Bill;
        private Guna.UI2.WinForms.Guna2CircleButton less;
        private Guna.UI2.WinForms.Guna2CircleButton more;
        private Guna.UI2.WinForms.Guna2TextBox Amount;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurant_V2
{
    public partial class admin2 : Form
    {

        public static string Default = "Data Source=.;database=RestaurantV2;Integrated security=True";
        public admin2()
        {
            InitializeComponent();
        }

        public void ReadData()
        {
            try
            {
                SqlConnection conn = new SqlConnection(Default);
                using (SqlCommand cmd = new SqlCommand("SELECT * from Foods", conn))
                {
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        DataTable dt = new DataTable();
                        dt.Load(reader);
                        dataGridView1.DataSource = dt;
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void admin2_Load(object sender, EventArgs e)
        {
            ReadData();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ReadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(Description.Text) && !string.IsNullOrWhiteSpace(Price.Text) && !string.IsNullOrWhiteSpace(Name.Text))
            {
                SqlConnection conn = new SqlConnection(Default);
                string AddQuery = "INSERT INTO Foods (Name,Price,Description) Values(@name,@price,@description)";
                using (SqlCommand cmd = new SqlCommand(AddQuery, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@name", Name.Text);
                    cmd.Parameters.AddWithValue("@price", Price.Text);
                    cmd.Parameters.AddWithValue("@description", Description.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("added successfully!", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conn.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection(Default);  
            string UpdateName = "UPDATE Foods set Name = @name where id = @id";
            string UpdatePrice = "UPDATE Foods set Price = @price where id = @id";
            string UpdateDescription = "UPDATE Foods set Description = @description where id = @id";

            if (Name.Text != "")
            {
                using (SqlCommand cmd = new SqlCommand(UpdateName, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@id", ID.Text);
                    cmd.Parameters.AddWithValue("@name", Name.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Updated successfully!", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conn.Close();
                }
            }
            if (Price.Text != "")
            {
                using (SqlCommand cmd = new SqlCommand(UpdatePrice, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@id", ID.Text);
                    cmd.Parameters.AddWithValue("@price", Price.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Updated successfully!", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conn.Close();
                }
            }
            if (Description.Text != "")
            {
                using (SqlCommand cmd = new SqlCommand(UpdateDescription, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@id", ID.Text);
                    cmd.Parameters.AddWithValue("@description", Description.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Updated successfully!", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conn.Close();
                }
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(Default);
            string DeleteQuery = "DELETE from Foods WHERE ID = @id";
            using (SqlCommand cmd = new SqlCommand(DeleteQuery, conn))
            {
                conn.Open();
                cmd.Parameters.AddWithValue("@id", ID.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("deleted successfully!", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conn.Close();
            }
        }

        private void ShowBills_Click(object sender, EventArgs e)
        {
            Bills the_Bills = new Bills();
            the_Bills.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurant_V2
{
    public partial class Bills : Form
    {
        public static string Default = "Data Source=.;database=BillsV2;Integrated security=True";
        public Bills()
        {
            InitializeComponent();
        }

        private void Bills_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(Default);
            using (SqlCommand cmd = new SqlCommand("SELECT * from Bill", conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView1.DataSource = dt;
                }
                conn.Close();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            admin2 admin2 = new admin2();
            admin2.Show();
            this.Hide();
        }
    }
}
